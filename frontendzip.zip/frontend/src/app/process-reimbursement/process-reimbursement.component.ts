import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ProcessReimbursement } from '../models/process-reimbursement';
import { Reimbursement } from '../models/reimbursement';
import { ProcessReimbursementService } from '../services/process-reimbursement.service';
import { ReimbursementlistService } from '../services/reimbursementlist.service';

@Component({
  selector: 'app-process-reimbursement',
  templateUrl: './process-reimbursement.component.html',
  styleUrls: ['./process-reimbursement.component.css']
})
export class ProcessReimbursementComponent implements OnInit {

  reimbursementForm: FormGroup;
  id:number;
  reimburse:Reimbursement;
  processReimbursement:ProcessReimbursement=new ProcessReimbursement();

  constructor(private reimbursement:ReimbursementlistService,private route:ActivatedRoute,private processReimburseService:ProcessReimbursementService ) {
  
    this.showReimbursementData();
  }
  showReimbursementData(){
    this.id=this.route.snapshot.params['reimbursementId']
    this.reimbursement.getReimbursementById(this.id)
    .subscribe((data)=>{
      this.reimburse = data

    },
    error=>console.log(error))
  }

  ngOnInit(): void {
    
    this.reimbursementForm = new FormGroup({
      
      'status': new FormControl('',Validators.required),
      'remarks': new FormControl(null,Validators.compose([
        Validators.required,
      ])),
      'requestProcessedByEmployeeId':new FormControl(null,Validators.required)
    });
    this.showReimbursementData();
  }

  onSubmit(id:any) {
      
      this.processReimbursement.id=id;
      this.processReimbursement.remarks=this.reimbursementForm.value.remarks;
      this.processReimbursement.requestProcessedByEmployeeId= this.reimbursementForm.value.requestProcessedByEmployeeId;
      this.processReimbursement.status=this.reimbursementForm.value.status;
    
    
    this.processReimburseService.processReimbursement(this.processReimbursement,this.reimburse.id).subscribe(data=>{
      
    });
    this.showReimbursementData();
    this.reimbursementForm.reset();
  }

  remarksValidator(control: FormControl): {[s: string]: boolean} {
    if (this.reimbursementForm && this.reimbursementForm.get('status').value === 'Rejected' && (!control.value || control.value.trim() === '')) {
      return {'remarksRequired': true};
    }
    return null;
  }
}
