import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewReimbursementComponent } from './new-reimbursement/new-reimbursement.component';
import { ReimbursementsListComponent } from './reimbursements-list/reimbursements-list.component';
import { ProcessReimbursementComponent } from './process-reimbursement/process-reimbursement.component';
import { EmployeeGuard } from './auth-service/empolyee.guard';
import { TravelDeskExecutiveGuard } from './auth-service/TravelDeskExecutive.guard';
import { TravelDeskExecutiveEmpolyeeGuard } from './auth-service/travelDeskExecurive-employee.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'reimbursements-list' , component:ReimbursementsListComponent,canActivate:[TravelDeskExecutiveEmpolyeeGuard]},
  {path:'new-reimbursement',component:NewReimbursementComponent,canActivate:[EmployeeGuard]},
  {path:'process-reimbursement/:reimbursementId',component:ProcessReimbursementComponent,canActivate:[TravelDeskExecutiveGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
