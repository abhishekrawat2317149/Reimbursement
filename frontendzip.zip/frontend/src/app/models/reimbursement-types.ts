export class ReimbursementTypes {   

    public id: number;
    public type: String;
}
