export class ProcessReimbursement {

    public id: number;
    public requestProcessedByEmployeeId: number;
    public status: String;
    public remarks: String;

}
