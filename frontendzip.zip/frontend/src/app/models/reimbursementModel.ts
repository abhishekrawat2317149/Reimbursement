export class   ReimbursementObj{ 
    reimbursementId!:number;
    travelrequestid!:number ;
    requestRaisedByEmployeeId!:number ;
    reimbursementTypesId!: number;

    invoiceNo!: string;
    invoiceDate!: Date; 
    invoiceAmount!: number;
    documentUrl!: string 
}