export class Reimbursement {
     id:number;
     travelrequestid: number;
     requestRaisedByEmployeeId: number;
     reimbursementTypesId: number;
     invoiceNo: String;
     invoiceDate: Date;
     invoiceAmount: number;
     documentUrl: String;

}
