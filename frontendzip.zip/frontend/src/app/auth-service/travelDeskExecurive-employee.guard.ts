import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';

export const TravelDeskExecutiveEmpolyeeGuard: CanActivateFn = (route, state) => {
  const authService=inject(AuthenticationService);
  const router=inject(Router);

  if(authService.isUserLoggedIn() && (authService.isUserTravelDeskExecutive()|| authService.isUserEmployee()) ){
    return true;
  }
  else if(authService.isUserLoggedIn() && (!authService.isUserTravelDeskExecutive()|| !authService.isUserEmployee())){
    alert("Not authorized");
    return false;
  }
  else{
    router.navigate(['/login']);
    return false;
  }
};
