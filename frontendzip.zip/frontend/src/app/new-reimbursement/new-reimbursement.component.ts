import { Component } from '@angular/core';
import { Reimbursement } from '../models/reimbursement';
import { ReimbursementTypes } from '../models/reimbursement-types';
import { NewreimbursementService } from '../services/newreimbursement.service';
import { AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-new-reimbursement',
  templateUrl: './new-reimbursement.component.html',
  styleUrls: ['./new-reimbursement.component.css'] 
})
export class NewReimbursementComponent {
  
  constructor(private reimbursedata:NewreimbursementService){ 
    
  }
  reimbursementTypes: ReimbursementTypes[] = [
    {id: 1, type: 'Travel'},
    {id: 2, type: 'Laundry'},
    {id: 3, type: 'Food and Water'}
  ];
  reimbursement: Reimbursement= new Reimbursement();
  getTodayDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = (today.getMonth() + 1).toString().padStart(2, '0');
    const day = today.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}
isDateInPast(selectedDate: Date): boolean {
  const today = new Date();
  return selectedDate < today;
}

  onClick(){


    this.reimbursedata.savenewreimbursement(this.reimbursement).subscribe((data)=>{
  
      alert("Data Submitted Successfully");
      window.location.reload();
    },
    error=>{
      console.log(error.error);
    }); 
 
   }
  }

export function dateValidator(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();

    if (selectedDate < currentDate) {
        return { pastDate: true }; 
    }

    return null;
}
