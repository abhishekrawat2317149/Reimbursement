import { Component, OnInit } from '@angular/core';
import { ReimbursementObj } from '../models/reimbursementModel';
import { Reimbursement } from '../models/reimbursement';
import { ReimbursementlistService } from '../services/reimbursementlist.service';


@Component({
  selector: 'app-reimbursements-list',
  templateUrl: './reimbursements-list.component.html',
  styleUrls: ['./reimbursements-list.component.css']
})
export class ReimbursementsListComponent implements OnInit {

  travelRequestId: number;
  role:string;

  constructor(private reimbursement:ReimbursementlistService) {}

  ngOnInit(): void {
    this.role=sessionStorage.getItem('role');
  }
  reimbursementObj=new Reimbursement();

  submitTravelRequestId() {
    

    this.reimbursement.getReimbursementById(this.travelRequestId)
    .subscribe((data)=>{
      this.reimbursementObj = data
    },error=>console.log(error))

  }

  

}


