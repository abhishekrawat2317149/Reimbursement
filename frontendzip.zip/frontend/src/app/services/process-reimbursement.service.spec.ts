import { TestBed } from '@angular/core/testing';

import { ProcessReimbursementService } from './process-reimbursement.service';

describe('ProcessReimbursementService', () => {
  let service: ProcessReimbursementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProcessReimbursementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
