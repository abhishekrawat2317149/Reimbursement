import { TestBed } from '@angular/core/testing';

import { ReimbursementlistService } from './reimbursementlist.service';

describe('ReimbursementlistService', () => {
  let service: ReimbursementlistService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReimbursementlistService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
