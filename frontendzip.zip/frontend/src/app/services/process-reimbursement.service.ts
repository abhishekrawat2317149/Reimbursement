import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ProcessReimbursement } from '../models/process-reimbursement';
//import { Reimbursement } from '../reimbursement';

@Injectable({
  providedIn: 'root'
})

export class ProcessReimbursementService {
  processReimbursementUrl="localhost:8084/api/reimbursements";
  constructor(private http:HttpClient) { }
  processReimbursement(data:ProcessReimbursement,id:number){
    return this.http.put<any>("http://localhost:8084/api/reimbursements/"+id+"/process",data);
  } 
}
