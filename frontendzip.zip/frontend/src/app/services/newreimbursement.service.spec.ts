import { TestBed } from '@angular/core/testing';

import { NewreimbursementService } from './newreimbursement.service';

describe('NewreimbursementService', () => {
  let service: NewreimbursementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewreimbursementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
