import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Reimbursement } from '../models/reimbursement';

@Injectable({
  providedIn: 'root'
})
export class NewreimbursementService {

  newreimbursementurl="http://localhost:8084/api/reimbursements/add";
  constructor(private http:HttpClient) { }
  savenewreimbursement(data:Reimbursement){
    return this.http.post<Reimbursement>(this.newreimbursementurl,data);
  }
}
