import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
//import { Observable } from 'rxjs';
import { Reimbursement } from '../models/reimbursement';

@Injectable({
  providedIn: 'root'
})
export class ReimbursementlistService {
 
  constructor(private http:HttpClient) { }


  getReimbursementById(id:any){
    return this.http.get<Reimbursement>(`http://localhost:8084/api/reimbursements/${id}/requests`)

  }


}
