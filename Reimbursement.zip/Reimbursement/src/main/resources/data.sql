insert into types values(1,'Travel'),(2,'Laundry'),(3,'Food and Water');
insert into requests(TRAVELREQUESTID,REQUESTRAISEDBYEMPLOYEEID,REQUESTPROCESSEDBYEMPLOYEEID,REIMBURSEMENTTYPEID,INVOICENO,INVOICEDATE,INVOICEAMOUNT,DOCUMENTURL) 
values(1001,1076,1,3,'1081','2024-02-22',1200,'C:\\Users\\2317239\\Downloads\\sts-4.21.0.RELEASE');
insert into users 
values('employee','employee123', 'employee','false' ),
('traveldesk','traveldesk123', 'traveldeskexecutive','false');
