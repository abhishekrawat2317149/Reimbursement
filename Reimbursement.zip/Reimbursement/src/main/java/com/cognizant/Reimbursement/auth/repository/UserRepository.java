package com.cognizant.Reimbursement.auth.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Reimbursement.auth.entities.Users;

@Repository
public interface UserRepository extends CrudRepository<Users,String>{

}
