package com.cognizant.Reimbursement.models;

import java.time.LocalDate;

import com.cognizant.Reimbursement.validators.Status;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.PastOrPresent;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AddNewReimbursementDTO {
	
	private int travelrequestid;

	private int requestRaisedByEmployeeId;

	private LocalDate requestDate;

	private int reimbursementTypesId;

	private String invoiceNo;

	@PastOrPresent
	private LocalDate invoiceDate;

	private int invoiceAmount;

	private String documentUrl;
	@Enumerated(EnumType.STRING)
	private Status status;

	public String getStatus() {
		return status.name();
	}

	public void setStatus(String status) throws IllegalArgumentException {
		this.status = Status.valueOf(status);
	}

	public AddNewReimbursementDTO() {
		super();
		requestDate = LocalDate.now();
		status = Status.valueOf("New");
	}


	

}
