package com.cognizant.Reimbursement.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Reimbursement.models.AddNewReimbursementDTO;
import com.cognizant.Reimbursement.models.ProcessReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementTypesDTO;
import com.cognizant.Reimbursement.services.ReimbursementService;
import com.cognizant.Reimbursement.services.ReimbursementServiceImpl;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
/**
 * This is controller class
 * 
 **/
@RestController
@RequestMapping("api")
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class ReimbursementController {
	@Autowired
	private ReimbursementService reimbursementServiceImpl;

	// EndPoint 1 ...
	@GetMapping("reimbursements/types")
	public ResponseEntity<?> getAllReimbursementTypes() {
		List<ReimbursementTypesDTO> responseList = reimbursementServiceImpl.getAvailableReimbursementTypes();
		ResponseEntity<List<ReimbursementTypesDTO>> responseEntity = null;
		if (!responseList.isEmpty()) {
			responseEntity = new ResponseEntity<List<ReimbursementTypesDTO>>(responseList, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		log.info("response Entity:"+responseEntity);
		return responseEntity;
	}

	// EndPoint 2
	@PostMapping("reimbursements/add")
	public ResponseEntity<?> addNewReimbursement( @RequestBody AddNewReimbursementDTO addNewReimbursementDTO) {
		String result = reimbursementServiceImpl.addReimbursement(addNewReimbursementDTO);
		Map<String,String> map=new HashMap<>();
		if (result.equals("success")) {
			map.put("message", "Created");
			return new ResponseEntity<>(map, HttpStatus.CREATED);
		} else {
			map.put("'meesage", "Not Created");
			return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
		}

	}

	// EndPoint 3
	@GetMapping("reimbursements/{travelrequestid}/requests")
	public ResponseEntity<?> getAllReimbursementByTravelRequestId(@PathVariable("travelrequestid") int travelrequestid) {

		ReimbursementDTO reimbursementDTO = reimbursementServiceImpl.getAllReimbursentsByTravelRequestId(travelrequestid);
		ResponseEntity<ReimbursementDTO> responseEntity = null;
		if (reimbursementDTO.getId()!=0) {
	
			responseEntity = new ResponseEntity<ReimbursementDTO>(reimbursementDTO, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		log.info("response Entity:"+responseEntity);
		return responseEntity;
		
	}

	// EndPoint 4
	@GetMapping("reimbursements/{id}")
	public ResponseEntity<?> getReimbursementById(@PathVariable("id") int id) {
		ReimbursementDTO reimbursementDTO = reimbursementServiceImpl.getReimbursementById(id);
		ResponseEntity<ReimbursementDTO> responseEntity = null;
		if (reimbursementDTO.getId() != 0) {
			responseEntity = new ResponseEntity<ReimbursementDTO>(reimbursementDTO, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		log.info("response Entity:"+responseEntity);
		return responseEntity;
	}

	// EndPoint 5
	@PutMapping("reimbursements/{reimbursementid}/process")
	public ResponseEntity<?> processReimbursements(@PathVariable int reimbursementid,
			@Valid @RequestBody ProcessReimbursementDTO processReimbursementDTO) {

		String result = reimbursementServiceImpl.processReimbursementRequests(processReimbursementDTO,reimbursementid);
		if (result.equals("success")) {
			return new ResponseEntity<>("Updated", HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED);
		}
	}

}
