package com.cognizant.Reimbursement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.Reimbursement.entities.ReimbursementTypes;

public interface TypeRepository extends JpaRepository<ReimbursementTypes, Integer> {
}
