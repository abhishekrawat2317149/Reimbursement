package com.cognizant.Reimbursement.validators;

public enum Status {
	New,
	Approved,
	Rejected
}
