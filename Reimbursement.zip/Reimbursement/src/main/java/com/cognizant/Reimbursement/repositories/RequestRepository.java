package com.cognizant.Reimbursement.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.Reimbursement.entities.ReimbursementRequests;

public interface RequestRepository extends JpaRepository<ReimbursementRequests, Integer> {
	ReimbursementRequests findByTravelrequestid(int travelrequestid);
}
