package com.cognizant.Reimbursement.auth.service;

import java.util.List;

import com.cognizant.Reimbursement.auth.entities.Users;
import com.cognizant.Reimbursement.auth.model.UserDTO;


public interface UserService {
	
	public List<Users> listOfUsers();
	public UserDTO authenticateUser(String username,String password);

}
