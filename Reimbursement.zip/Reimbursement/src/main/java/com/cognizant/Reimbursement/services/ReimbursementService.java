package com.cognizant.Reimbursement.services;

import java.util.List;

import com.cognizant.Reimbursement.models.AddNewReimbursementDTO;
import com.cognizant.Reimbursement.models.ProcessReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementTypesDTO;

public interface ReimbursementService {
	public List<ReimbursementTypesDTO> getAvailableReimbursementTypes();
	public String addReimbursement(AddNewReimbursementDTO addNewReimbursementDTO);
	public ReimbursementDTO getAllReimbursentsByTravelRequestId(int id);
	public ReimbursementDTO getReimbursementById(int id);
	public String processReimbursementRequests(ProcessReimbursementDTO dto,int id);
}

