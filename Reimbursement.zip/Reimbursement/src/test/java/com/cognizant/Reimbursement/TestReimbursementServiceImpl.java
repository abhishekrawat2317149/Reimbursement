package com.cognizant.Reimbursement;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.Reimbursement.entities.ReimbursementRequests;
import com.cognizant.Reimbursement.entities.ReimbursementTypes;
import com.cognizant.Reimbursement.models.AddNewReimbursementDTO;
import com.cognizant.Reimbursement.models.ProcessReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementDTO;
import com.cognizant.Reimbursement.models.ReimbursementTypesDTO;
import com.cognizant.Reimbursement.repositories.RequestRepository;
import com.cognizant.Reimbursement.repositories.TypeRepository;
import com.cognizant.Reimbursement.services.ReimbursementServiceImpl;

@SpringBootTest
//@ContextConfiguration(classes = ReimbursementApplication.class)
class TestReimbursementServiceImpl {
	@Mock
	private RequestRepository requestRepository;

	@Mock
	private TypeRepository typeRepository;
	@InjectMocks
	ReimbursementServiceImpl reimbursementServices;

	@Test
	void testGetAvailableReimbursementTypes_Positive() {
		try {
			ReimbursementTypes reimbursementTypes = new ReimbursementTypes();
			reimbursementTypes.setId(1);
			reimbursementTypes.setType("Food");
			ReimbursementTypes reimbursementTypes1 = new ReimbursementTypes();
			reimbursementTypes1.setId(2);
			reimbursementTypes1.setType("Water");
			List<ReimbursementTypes> mockTypes = Arrays.asList(reimbursementTypes, reimbursementTypes1);

			// Mock repository behavior
			Mockito.when(typeRepository.findAll()).thenReturn(mockTypes);

			// Call the service method
			List<ReimbursementTypesDTO> dtos = reimbursementServices.getAvailableReimbursementTypes();

			// Verify the result
			assertTrue(!dtos.isEmpty());
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	void testAddReimbursement_Positive() {
		try {
			// Create a sample AddNewReimbursementDTO with a small document size
			AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
			mockDTO.setTravelrequestid(1001);
			mockDTO.setDocumentUrl("C:\\Users\\2317149\\Downloads\\Restaurant_Sample_Invoice.pdf");
			mockDTO.setInvoiceAmount(1200);
			mockDTO.setInvoiceDate(LocalDate.parse("2028-02-29"));
			mockDTO.setInvoiceNo("INV001");
			mockDTO.setReimbursementTypesId(2);
			mockDTO.setRequestRaisedByEmployeeId(1001);
			ReimbursementRequests reimbursementRequests = new ReimbursementRequests();
			reimbursementRequests.setTravelrequestid(mockDTO.getTravelrequestid());
			reimbursementRequests.setRequestRaisedByEmployeeId(mockDTO.getRequestRaisedByEmployeeId());
			reimbursementRequests.setRequestDate(mockDTO.getRequestDate());
			ReimbursementTypes reimbursementTypes = new ReimbursementTypes();
			reimbursementTypes.setId(mockDTO.getReimbursementTypesId());
			reimbursementTypes.setType("Laundry");
			reimbursementRequests.setReimbursementTypes(reimbursementTypes);
			reimbursementRequests.setInvoiceNo(mockDTO.getInvoiceNo());
			reimbursementRequests.setInvoiceDate(mockDTO.getInvoiceDate());
			reimbursementRequests.setInvoiceAmount(mockDTO.getInvoiceAmount());
			reimbursementRequests.setDocumentUrl(mockDTO.getDocumentUrl());

			Mockito.when(typeRepository.findById(mockDTO.getReimbursementTypesId()))
					.thenReturn(Optional.of(reimbursementTypes));
			// Mocking behavior for the repository save method
			Mockito.when(requestRepository.save(Mockito.any(ReimbursementRequests.class)))
					.thenReturn(reimbursementRequests);

			// Call the method under test
			String result = reimbursementServices.addReimbursement(mockDTO);
			assertEquals("fail", result);
		} catch (Exception e) {
			assertTrue(false);
		}
	}


	@Test
	void testGetAllReimbursentsByTravelRequestId_Positive() {

		try {
			ReimbursementTypes reimbursementTypes = new ReimbursementTypes();
			reimbursementTypes.setId(3);
			reimbursementTypes.setType("Food and Water");
			ReimbursementRequests reimbursementRequests1 = new ReimbursementRequests();
			reimbursementRequests1.setTravelrequestid(1001);
			reimbursementRequests1.setReimbursementTypes(reimbursementTypes);
			ReimbursementRequests reimbursementRequests2 = new ReimbursementRequests();
			reimbursementRequests2.setTravelrequestid(1001);
			reimbursementRequests2.setReimbursementTypes(reimbursementTypes);
			ReimbursementDTO dto1 = new ReimbursementDTO();
			dto1.setTravelRequestId(reimbursementRequests1.getTravelrequestid());
			dto1.setReimbursementTypesId(reimbursementTypes.getId());
			ReimbursementDTO dto2 = new ReimbursementDTO();
			dto2.setTravelRequestId(reimbursementRequests2.getTravelrequestid());
			dto2.setReimbursementTypesId(reimbursementTypes.getId());

			//List<ReimbursementRequests> mockRequests = Arrays.asList(reimbursementRequests1, reimbursementRequests2
			// Add more mock data as needed
			//);

			// Mock repository behavior
			Mockito.when(requestRepository.findByTravelrequestid(1001)).thenReturn(reimbursementRequests1);

			// Call the service method
			ReimbursementDTO result = reimbursementServices.getAllReimbursentsByTravelRequestId(1001);

			// Verify the result
			assertNotNull(result);
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	void testGetReimbursementById_Positive() {
		try {
			ReimbursementRequests mockReimbursementRequest = new ReimbursementRequests();
			mockReimbursementRequest.setTravelrequestid(123);
			mockReimbursementRequest.setRequestRaisedByEmployeeId(456);
			mockReimbursementRequest.setId(1);
			mockReimbursementRequest.setInvoiceNo("INV123");
			ReimbursementTypes mockReimbursementTypes = new ReimbursementTypes();
			mockReimbursementTypes.setId(3);
			mockReimbursementRequest.setReimbursementTypes(mockReimbursementTypes);

			Mockito.when(requestRepository.findById(mockReimbursementRequest.getId()))
					.thenReturn(Optional.of(mockReimbursementRequest));

			// Call the service method
			ReimbursementDTO result = reimbursementServices.getReimbursementById(1);
			assertNotNull(result);

		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	void testProcessReimbursementRequests_Positive() {
		try {
			ProcessReimbursementDTO mockDTO = new ProcessReimbursementDTO();
			mockDTO.setReimbursementId(1);
			mockDTO.setRemarks("Approved");
			mockDTO.setRequestProcessedByEmployeeId(1002);
			mockDTO.setRequestProcessedOn(LocalDate.now());
			mockDTO.setRequestRaisedByEmployeeId(101);
			mockDTO.setStatus("Approved");
			mockDTO.setRequestRaisedByEmployeeId(1001);
			ReimbursementRequests reimbursementRequests = new ReimbursementRequests();
			reimbursementRequests.setId(mockDTO.getReimbursementId());
			reimbursementRequests.setRequestProcessedOn(mockDTO.getRequestProcessedOn());
			reimbursementRequests.setRequestProcessedByEmployeeId(mockDTO.getRequestProcessedByEmployeeId());
			reimbursementRequests.setStatus(mockDTO.getStatus());
			reimbursementRequests.setRemarks(mockDTO.getRemarks());
			Mockito.when(requestRepository.findById(reimbursementRequests.getId()))
					.thenReturn(Optional.of(reimbursementRequests));

			Mockito.when(requestRepository.save(Mockito.any(ReimbursementRequests.class)))
					.thenReturn(reimbursementRequests);
//			System.out.println(reimbursementRequests.getStatus());
			String result = reimbursementServices.processReimbursementRequests(mockDTO,1);

			// Assert that the result is not null (indicating success)
			assertNotNull(result);
		} catch (Exception e) {
			assertTrue(false);
		}

	}
	// Additional Negative Test Cases
	 
	@Test
	void testAddReimbursement_InvalidDocumentUrl() {
	    AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
	    mockDTO.setDocumentUrl("invalid_url");
	 
	    String result = reimbursementServices.addReimbursement(mockDTO);
	 
	    assertEquals("fail", result);
	}
	 
	@Test
	void testAddReimbursement_PastInvoiceDate() {
	    AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
	    mockDTO.setInvoiceDate(LocalDate.now().minusDays(1));
	 
	    String result = reimbursementServices.addReimbursement(mockDTO);
	 
	    assertEquals("fail", result);
	}
	 
	@Test
	void testAddReimbursement_NegativeInvoiceAmount() {
	    AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
	    mockDTO.setInvoiceAmount(-500);
	 
	    String result = reimbursementServices.addReimbursement(mockDTO);
	 
	    assertEquals("fail", result);
	}
	 
	@Test
	void testAddReimbursement_InvalidReimbursementType() {
	    AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
	    mockDTO.setReimbursementTypesId(999);
	 
	    String result = reimbursementServices.addReimbursement(mockDTO);
	 
	    assertEquals("fail", result);
	}
	 
	// Additional Exception Test Cases
	 
	@Test
	void testAddReimbursement_SaveFailure() {
	    AddNewReimbursementDTO mockDTO = new AddNewReimbursementDTO();
	 
	    Mockito.when(typeRepository.findById(mockDTO.getReimbursementTypesId()))
	            .thenReturn(Optional.of(new ReimbursementTypes()));
	 
	    Mockito.when(requestRepository.save(Mockito.any(ReimbursementRequests.class)))
	            .thenThrow(new RuntimeException("Failed to save"));
	 
	    String result = reimbursementServices.addReimbursement(mockDTO);
	 
	    assertEquals("fail", result);
	}
	 
	@Test
	void testProcessReimbursementRequests_NullDTO() {
	    try {
	    	String result = reimbursementServices.processReimbursementRequests(null,1);
	   	 
		    assertEquals("fail", result);
	    }catch (Exception e) {
			assertFalse(false);
		}
	}
	 
	@Test
	void testProcessReimbursementRequests_InvalidReimbursementId() {
		try {
	    ProcessReimbursementDTO mockDTO = new ProcessReimbursementDTO();
	    mockDTO.setReimbursementId(999);
	 
	    String result = reimbursementServices.processReimbursementRequests(mockDTO,1);
	 
	    assertEquals("fail", result);
		}catch(Exception e) {
			assertTrue(true);
		}
	}
	 
	@Test
	void testProcessReimbursementRequests_InvalidStatus() {
	    try {
	    	ProcessReimbursementDTO mockDTO = new ProcessReimbursementDTO();
		    mockDTO.setStatus("InvalidStatus");
		 
		    String result = reimbursementServices.processReimbursementRequests(mockDTO,1);
		 
		    assertEquals("fail", result);
	    }catch (Exception e) {
			assertFalse(false);
		}
	}

}
