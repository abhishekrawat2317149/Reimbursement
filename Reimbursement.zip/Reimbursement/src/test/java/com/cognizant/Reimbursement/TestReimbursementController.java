package com.cognizant.Reimbursement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;

import com.cognizant.Reimbursement.controllers.ReimbursementController;
import com.cognizant.Reimbursement.models.ReimbursementTypesDTO;
import com.cognizant.Reimbursement.services.ReimbursementService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.constraints.AssertFalse.List;

//@AutoConfigureMockMvc
//@WebMvcTest
//@ContextConfiguration(classes = ReimbursementApplication.class)
public class TestReimbursementController {

	private MockMvc mockMvc;
	@Mock
	private ReimbursementService reimbursementService;
	@InjectMocks
	private ReimbursementController reimbursementController;
	@Mock
	private RestTemplate restTemplate;
	@Autowired
	private LocalValidatorFactoryBean validator;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc=MockMvcBuilders.standaloneSetup(reimbursementController).build();
	}
	
	
	
	@Test
	public void handleGetAllEmployees_positiveReturnValue() {
		try {
		ArrayList<ReimbursementTypesDTO> mockListOfReimbursementTypesDTO=new ArrayList<>();
		ReimbursementTypesDTO reimbursementTypesDTO=new ReimbursementTypesDTO();
		reimbursementTypesDTO.setId(3);
		reimbursementTypesDTO.setType("Travel");
		mockListOfReimbursementTypesDTO.add(reimbursementTypesDTO);
		when(reimbursementService.getAvailableReimbursementTypes()).thenReturn(mockListOfReimbursementTypesDTO);
		
		ResponseEntity<?> responseEntity=reimbursementController.getAllReimbursementTypes();
		ArrayList<ReimbursementTypesDTO> actual=(ArrayList<ReimbursementTypesDTO>)responseEntity.getBody();
		assertTrue(actual.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void handleGetAllEmployees_NegetiveReturnValue() {
		try {
		ArrayList<ReimbursementTypesDTO> mockListOfReimbursementTypesDTO=new ArrayList<>();
		when(reimbursementService.getAvailableReimbursementTypes()).thenReturn(mockListOfReimbursementTypesDTO);
		
		ResponseEntity<?> responseEntity=reimbursementController.getAllReimbursementTypes();
		assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void handleGetAllEmployees_positiveStatusCode() {
		try {
		ArrayList<ReimbursementTypesDTO> mockListOfReimbursementTypesDTO=new ArrayList<>();
		ReimbursementTypesDTO reimbursementTypesDTO=new ReimbursementTypesDTO();
		reimbursementTypesDTO.setId(3);
		reimbursementTypesDTO.setType("Travel");
		mockListOfReimbursementTypesDTO.add(reimbursementTypesDTO);
		when(reimbursementService.getAvailableReimbursementTypes()).thenReturn(mockListOfReimbursementTypesDTO);
		ResponseEntity<?> responseEntity=reimbursementController.getAllReimbursementTypes();
		assertEquals(200,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	
	
	@Test
	public void handleGetAllEmployees_NegetiveStatusCode() {
		try {
		ArrayList<ReimbursementTypesDTO> mockListOfReimbursementTypesDTO=new ArrayList<>();
		when(reimbursementService.getAvailableReimbursementTypes()).thenReturn(mockListOfReimbursementTypesDTO);
		ResponseEntity<?> responseEntity=reimbursementController.getAllReimbursementTypes();
		assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
}
