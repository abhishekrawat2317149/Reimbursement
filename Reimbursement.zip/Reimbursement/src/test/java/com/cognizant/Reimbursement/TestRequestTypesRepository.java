package com.cognizant.Reimbursement;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.Reimbursement.ReimbursementApplication;
import com.cognizant.Reimbursement.entities.ReimbursementTypes;
import com.cognizant.Reimbursement.repositories.TypeRepository;
@DataJpaTest
@ContextConfiguration(classes=ReimbursementApplication.class)
class TestRequestTypesRepository {

	@Autowired
	private TypeRepository typeRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllTypesPositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(4);
		reimbursementTypes.setType("XYZ SERVICES");
		entityManager.persist(reimbursementTypes);
		Iterable<ReimbursementTypes>it=typeRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testSavePositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(4);
		reimbursementTypes.setType("XYZ SERVICES");
		typeRepository.save(reimbursementTypes);
		Optional<ReimbursementTypes> type=typeRepository.findById(4);
		assertTrue(type.isPresent());
	}
	@Test
	public void testFindByIdPositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(4);
		reimbursementTypes.setType("XYZ SERVICES");
		typeRepository.save(reimbursementTypes);
		Optional<ReimbursementTypes> type=typeRepository.findById(4);
		assertTrue(type.isPresent());
	}
	@Test
	public void testFindByIdNegaitive() {
		Optional<ReimbursementTypes> type=typeRepository.findById(4);
		assertFalse(type.isPresent());
	}

}
