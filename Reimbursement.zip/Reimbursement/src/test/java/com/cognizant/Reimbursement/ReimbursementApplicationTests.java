package com.cognizant.Reimbursement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.Reimbursement.ReimbursementApplication;

@SpringBootTest(classes = ReimbursementApplication.class)
class ReimbursementApplicationTests {

	@Test
	void contextLoads() {
	}

}
