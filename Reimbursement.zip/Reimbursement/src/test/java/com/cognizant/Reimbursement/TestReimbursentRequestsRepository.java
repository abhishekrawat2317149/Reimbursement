package com.cognizant.Reimbursement;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.Reimbursement.ReimbursementApplication;
import com.cognizant.Reimbursement.entities.ReimbursementRequests;
import com.cognizant.Reimbursement.entities.ReimbursementTypes;
import com.cognizant.Reimbursement.repositories.RequestRepository;
import com.cognizant.Reimbursement.repositories.TypeRepository;
@DataJpaTest
@ContextConfiguration(classes=ReimbursementApplication.class)
class TestReimbursentRequestsRepository {

	@Autowired
	private RequestRepository requestRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Autowired
	private TypeRepository typeRepository; 
	
	@Test
	public void testSavePositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(3);
		reimbursementTypes.setType("Laundry");
		typeRepository.save(reimbursementTypes);
		ReimbursementRequests reimbursementRequests=new ReimbursementRequests();
		reimbursementRequests.setId(2);
		reimbursementRequests.setTravelrequestid(1001);
		reimbursementRequests.setReimbursementTypes(reimbursementTypes);
		reimbursementRequests.setDocumentUrl("C:\\Users\\2317239\\OneDrive - Cognizant\\Documents\\Restaurant_Sample_Invoice.pdf");
		reimbursementRequests.setRequestDate(LocalDate.now());
//		entityManager.persist(reimbursementRequests);
		requestRepository.save(reimbursementRequests);
		Optional<ReimbursementRequests> request=requestRepository.findById(2);
		assertFalse(request.isPresent());
	}
	@Test
	public void testFindAllPositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(3);
//		reimbursementTypes.setType("Laundry");
//		entityManager.persist(reimbursementTypes);
		ReimbursementRequests reimbursementRequests=new ReimbursementRequests();
		//reimbursementRequests.setId(5);
		reimbursementRequests.setTravelrequestid(1001);
		reimbursementRequests.setReimbursementTypes(reimbursementTypes);
		reimbursementRequests.setDocumentUrl("C:\\Users\\2317239\\OneDrive - Cognizant\\Documents\\Restaurant_Sample_Invoice.pdf");
		reimbursementRequests.setRequestDate(LocalDate.now());
		entityManager.persist(reimbursementRequests);
		Iterable<ReimbursementRequests>it=requestRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegaitive() {
		Iterable<ReimbursementRequests>it=requestRepository.findAll();
		assertFalse(!it.iterator().hasNext());
	}
	@Test
	public void testFindByIdPositive() {
		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
		reimbursementTypes.setId(3);
		reimbursementTypes.setType("Laundry");
		//entityManager.persist(reimbursementTypes);
		ReimbursementRequests reimbursementRequests=new ReimbursementRequests();
		//reimbursementRequests.setId(8);
		reimbursementRequests.setTravelrequestid(1001);
		reimbursementRequests.setReimbursementTypes(reimbursementTypes);
		reimbursementRequests.setDocumentUrl("C:\\Users\\2317239\\OneDrive - Cognizant\\Documents\\Restaurant_Sample_Invoice.pdf");
		reimbursementRequests.setRequestDate(LocalDate.now());
		entityManager.persist(reimbursementRequests);
		//requestRepository.save(reimbursementRequests);
		Optional<ReimbursementRequests> request=requestRepository.findById(1);
		assertTrue(request.isPresent());
	}
	@Test
	public void testFindByIdNegaitive() {
		Optional<ReimbursementRequests> request=requestRepository.findById(7);
		assertFalse(request.isPresent());
	}
	@Test
	public void testFindByTravelRequestIdPositive() {
//		ReimbursementTypes reimbursementTypes=new ReimbursementTypes();
//		reimbursementTypes.setId(3);
//		reimbursementTypes.setType("Laundry");
//		entityManager.persist(reimbursementTypes);
//		ReimbursementRequests reimbursementRequests=new ReimbursementRequests();
		//reimbursementRequests.setId(5);
//		reimbursementRequests.setTravelrequestid(1001);
//		reimbursementRequests.setReimbursementTypes(reimbursementTypes);
//		reimbursementRequests.setDocumentUrl("C:\\Users\\2317239\\OneDrive - Cognizant\\Documents\\Restaurant_Sample_Invoice.pdf");
//		reimbursementRequests.setRequestDate(LocalDate.now());
//		entityManager.persist(reimbursementRequests);
		ReimbursementRequests it=requestRepository.findByTravelrequestid(1001);
		assertNotNull(it);
	}
	@Test
	public void testFindByTravelRequestIdNegative() {
		ReimbursementRequests it=requestRepository.findByTravelrequestid(1002);
		assertNull(it);
	}
	@Test
	public void testSaveNegative() {
		Iterable<ReimbursementRequests> it=requestRepository.findAll();
		assertFalse(!it.iterator().hasNext());
	}

}
